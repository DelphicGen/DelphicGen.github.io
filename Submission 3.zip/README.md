# SimpleSoccerApps-PWA-NoModuleBundler

It is the same as my SimpleSoccerApps-PWA-compelete file directory except for this one does not have module bundler

How to use
1. Clone the repository
2. Open the project in your favorite text editor
3. Open the terminal integrated in your text editor (if you choose to use normal terminal then remember to cd to project file)
4. Type npm install on terminal and press enter
5. You need web server to run the project. Personally I use Web Server for Chrome which is chrome extension 
   https://chrome.google.com/webstore/detail/web-server-for-chrome/ofhbbkphhbklhfoeikjpcbhemlocgigb?hl=en
   Those who does not use chrome can use another web server of your choice
